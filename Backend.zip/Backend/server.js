const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// MySQL connection setup
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Jncpg@2024', // Ensure this is correct
  database: 'jnc'
});

// Connect to MySQL and handle errors
db.connect(err => {
  if (err) {
    console.error('MySQL connection error:', err);
    process.exit(1); // Exit the process with an error code
  }
  console.log('MySQL Connected...');
});

// Get all students
app.get('/students', (req, res) => {
  const sql = 'SELECT * FROM students';
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error fetching students:', err);
      return res.status(500).send('An error occurred while fetching students.');
    }
    res.json(results);
  });
});

// Add a student
app.post('/students', (req, res) => {
  const { regNo, name, department, class: classValue } = req.body;
  const sql = 'INSERT INTO students (regNo, name, department, class) VALUES (?, ?, ?, ?)';
  db.query(sql, [regNo, name, department, classValue || null], (err, result) => {
    if (err) {
      console.error('Error adding student:', err);
      return res.status(500).send('An error occurred while adding the student.');
    }
    res.send('Student added...');
  });
});

// Update a student
app.put('/students/:regNo', (req, res) => {
  const { regNo } = req.params;
  const { name, department, class: classValue } = req.body;

  // Debugging logs
  console.log('Update request received:', { regNo, name, department, classValue });

  if (!name || !department) {
    return res.status(400).send('Name and department are required.');
  }

  const sql = 'UPDATE students SET name = ?, department = ?, class = ? WHERE regNo = ?';
  db.query(sql, [name, department, classValue || null, regNo], (err, result) => {
    if (err) {
      console.error('Error updating student:', err);
      return res.status(500).send('An error occurred while updating the student.');
    }
    
    // Check if any row was affected
    if (result.affectedRows === 0) {
      return res.status(404).send('Student not found.');
    }
    
    res.send('Student updated...');
  });
});

// Delete a student
app.delete('/students/:regNo', (req, res) => {
  const { regNo } = req.params;
  const sql = 'DELETE FROM students WHERE regNo = ?';
  db.query(sql, [regNo], (err, result) => {
    if (err) {
      console.error('Error deleting student:', err);
      return res.status(500).send('An error occurred while deleting the student.');
    }
    
    // Check if any row was affected
    if (result.affectedRows === 0) {
      return res.status(404).send('Student not found.');
    }
    
    res.send('Student deleted...');
  });
});

// Start the server
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

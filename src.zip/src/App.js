
import './App.css';
import StudentTable from './Components/StudentTable.js';

function App() {
  return (
    <div className="App">
      <StudentTable/>
     
    </div>
  );
}

export default App;
